import React from 'react';

function Services() {
  return (
    <div className="bg-white min-h-screen py-20">
      <div className="max-w-4xl mx-auto px-6">
        <h1 className="text-5xl font-bold text-gray-900 mb-6">Our Services</h1>
        <p className="text-xl text-gray-600 mb-12">
          Professional care services tailored to your family's needs.
        </p>

        <div className="space-y-8">
          <div className="border-l-4 border-[#5B7C99] pl-6">
            <h2 className="text-2xl font-bold text-gray-900 mb-3">Elder Care</h2>
            <p className="text-gray-700 leading-relaxed">
              Compassionate support for seniors including companionship, medication reminders, 
              meal preparation, and assistance with daily activities.
            </p>
          </div>

          <div className="border-l-4 border-[#5B7C99] pl-6">
            <h2 className="text-2xl font-bold text-gray-900 mb-3">Child Care</h2>
            <p className="text-gray-700 leading-relaxed">
              Trusted caregivers for children of all ages. From after-school care to full-time 
              nannies, all background-checked and experienced.
            </p>
          </div>

          <div className="border-l-4 border-[#5B7C99] pl-6">
            <h2 className="text-2xl font-bold text-gray-900 mb-3">Special Needs Care</h2>
            <p className="text-gray-700 leading-relaxed">
              Specialized caregivers trained to support individuals with physical or developmental 
              disabilities with dignity and respect.
            </p>
          </div>

          <div className="border-l-4 border-[#5B7C99] pl-6">
            <h2 className="text-2xl font-bold text-gray-900 mb-3">Medical Care</h2>
            <p className="text-gray-700 leading-relaxed">
              Licensed nurses (RN, LPN) for in-home medical care, wound care, medication 
              management, and post-surgical support.
            </p>
          </div>
        </div>

        <div className="mt-12 bg-[#E8F1F5] p-8 rounded-xl">
          <h3 className="text-2xl font-bold text-gray-900 mb-4">Need help choosing?</h3>
          <p className="text-gray-700 mb-6">
            Our care coordinators are here to help you find the perfect match for your needs.
          </p>
          <button className="bg-[#5B7C99] text-white px-8 py-3 rounded-lg hover:bg-[#4a6480] transition-all duration-300 font-semibold">
            Get Started
          </button>
        </div>
      </div>
    </div>
  );
}

export default Services;