import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar';
import Footer from './components/Footer';
import ScrollToTop from './components/ScrollToTop';
import Home from './pages/Home';
import Services from './pages/Services';
import Contact from './pages/Contact';
import SignUp from './pages/SignUp';

// This is your main App component with React Router!
// BrowserRouter wraps everything - it enables URL-based navigation
// ScrollToTop ensures every page starts at the top
// Routes contains all your Route definitions
// Each Route says "when URL is X, show component Y"

function App() {
  return (
    <Router>
      <ScrollToTop />
      <div className="min-h-screen bg-gray-50">
        {/* Navbar shows on every page */}
        <Navbar />
        
        {/* Routes define which component shows based on URL */}
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/services" element={<Services />} />
          <Route path="/contact" element={<Contact />} />
          <Route path="/signup" element={<SignUp />} />
        </Routes>
        
        {/* Footer shows on every page */}
        <Footer />
      </div>
    </Router>
  );
}

export default App;